# Tic Tac Toe

## Get started

Make sure you have Node.JS and yarn installed

```bash
yarn # install dependencies
```

## Start development server

```bash
yarn start:dev  # listening on prt 3000 by default with hot reload
```

## Run production build

```bash
yarn build
yarn start
```
