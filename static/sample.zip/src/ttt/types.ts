import { Action, State } from '../common/types'
export const FLIP_TABLE = '(╯°□°)╯︵ ┻━┻'

export enum TicTacToeTurn {
  O = 'O',
  X = 'X'
}

export type Board = Array<Array<TicTacToeTurn | null>>

export interface TicTacToeState extends State {
  turn: TicTacToeTurn
  board: Board
}

export enum TicTacToeActionType {
  PUT_SYMBOL = 'putSymbol',
  END_GAME = 'endGame',
}

export interface TicTacToeAction extends Action {
  type: TicTacToeActionType
  x?: number
  y?: number
  action2?: TicTacToeAction
}

export enum TicTacToeResult {
  O_WIN = 'O_WIN',
  X_WIN = 'X_WIN',
  DRAW = 'DRAW',
  FLIPPED = 'FLIPPED',
}

export interface ExternalAction {
  action: TicTacToeActionType
  position?: string
  player?: string // for outgoing only
  [other: string]: unknown
}
