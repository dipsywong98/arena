import { Router, Request } from 'express'

import workerFarm from 'worker-farm'

const workers = workerFarm(require.resolve('./candidate'))

const ticTacToeRouter = Router()

ticTacToeRouter.post('/', (req: Request<{}, {}, {battleId: string}>, res) => {
  res.send('OK')
  console.log(`received${req.body.battleId}`)
  workers(req.body.battleId, (...args: any[]) => {
    console.log(`done ${req.body.battleId}`, args)
  })
})

ticTacToeRouter.get('/', (req, res) => {
  res.redirect('/')
})

export default ticTacToeRouter
