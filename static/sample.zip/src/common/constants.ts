export const ARENA_URL = process.env.APP_URL ?? 'http://localhost:3003'
export const FLIP_TABLE = '(╯°□°)╯︵ ┻━┻'
export const END_GAME = 'endGame'
