export enum Game {
  TTT = 'ttt',
}

export interface State {
  turn: string
  expectFlip: boolean
  createdAt: number
}

export interface Action {
  type: string
  x?: number
  y?: number
  action2?: Action
}
